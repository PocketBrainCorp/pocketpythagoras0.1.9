//
//  RombDiagViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 06.12.2021.
//

import UIKit

class RombDiagViewController: UIViewController {

    
    @IBOutlet weak var d1: UITextField!
    @IBOutlet weak var d2: UITextField!
    @IBOutlet weak var result: UILabel!
    
    @IBAction func Res(_ sender: UIButton) {
        let d1 = Double(d1.text!) ?? 0.0
        let d2 = Double(d2.text!) ?? 0.0
        
        let S = (d1*d2)/2
        
        if (S - floor(S) == 0){
            result.text = String(Int(S))
        } else {
            result.text = String(S)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is SquareViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
