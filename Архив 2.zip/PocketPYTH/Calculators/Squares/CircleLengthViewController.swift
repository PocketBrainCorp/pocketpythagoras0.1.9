//
//  CircleLengthViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 07.12.2021.
//

import UIKit

class CircleLengthViewController: UIViewController {

    @IBOutlet weak var r: UITextField!
    @IBOutlet weak var result: UILabel!
    
    
    @IBAction func Res(_ sender: UIButton) {
        let r = Double(r.text!) ?? 0.0
        
        let L = 2*3.14*r
        
        if (L - floor(L) == 0) {
            result.text = String(Int(L))
        } else {
            result.text = String(L)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is LeftViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
