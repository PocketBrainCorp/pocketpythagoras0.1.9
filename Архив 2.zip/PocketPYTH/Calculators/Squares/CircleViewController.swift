//
//  CircleViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 07.12.2021.
//

import UIKit

class CircleViewController: UIViewController {

    
    @IBOutlet weak var r: UITextField!
    @IBOutlet weak var result: UILabel!
    
    @IBAction func Res(_ sender: UIButton) {
        let r = Double(r.text!) ?? 0.0
        
        let S = 3.14*r*r
        
        if (S - floor(S) == 0) {
            result.text = String(Int(S))
        } else {
            result.text = String(S)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is SquareViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
