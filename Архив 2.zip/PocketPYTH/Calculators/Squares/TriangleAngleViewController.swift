//
//  TriangleAngleViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 07.12.2021.
//

import UIKit

class TriangleAngleViewController: UIViewController {

    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var b: UITextField!
    @IBOutlet weak var angle: UITextField!
    @IBOutlet weak var result: UILabel!
    
    @IBAction func Res(_ sender: UIButton) {
        let a = Double(a.text!) ?? 0.0
        let b = Double(b.text!) ?? 0.0
        let angle = Double(angle.text!) ?? 0.0
        let alpha = sin(angle * M_PI / 180)
        
        let S = (1/2)*a*b*alpha
        if (S - floor(S) == 0){
            result.text = String(Int(S))
        } else if S - floor(S) != 0 && ((round(S) - S) <= 0.1){
            result.text = String(round(S))
        } else if S - floor(S) != 0 && ((round(S) - S) >= 0.1){
            result.text = String(S)
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is SquareViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
