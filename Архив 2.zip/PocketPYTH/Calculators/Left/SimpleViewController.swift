//
//  SimpleViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 07.12.2021.
//

import UIKit

class SimpleViewController: UIViewController {

    
    @IBOutlet weak var p: UITextField!
    @IBOutlet weak var result: UILabel!
    
    
    @IBAction func Res(_ sender: UIButton) {
        var p = Int(p.text!) ?? 0
        var count = 0
        if (p != 1 && p > 0){
            for j in 1...(p/2){
                if p%j == 0{
                    count += 1
                }
            }
            if count == 1 {
                result.text = String("Число простое")
            } else {
                result.text = String("Число составное")
            }
        } else if (p <= 0) {
            result.text = String("Не натуральное число")
        } else if (p == 1){
            result.text = String("Число ни простое, ни составное")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is LeftViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
