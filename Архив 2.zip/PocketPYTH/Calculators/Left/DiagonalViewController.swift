//
//  DiagonalViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 07.12.2021.
//

import UIKit

class DiagonalViewController: UIViewController {
    
    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var b: UITextField!
    @IBOutlet weak var c: UITextField!
    @IBOutlet weak var result: UILabel!
    
    
    @IBAction func Res(_ sender: UIButton) {
        let a  = Double(a.text!) ?? 0.0
        let b  = Double(b.text!) ?? 0.0
        let c  = Double(c.text!) ?? 0.0
        
        let L = sqrt(pow(a,2) + pow(b,2) + pow(c,2))
        
        if (L - floor(L) == 0) {
            result.text = String(Int(L))
        } else {
            result.text = String(L)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is LeftViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
